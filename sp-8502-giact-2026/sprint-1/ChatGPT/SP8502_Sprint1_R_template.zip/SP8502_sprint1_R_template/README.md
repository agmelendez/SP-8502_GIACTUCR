# SP-8502 · Sprint 1 — Plantilla de Proyecto en R (Reproducible)

Este template está alineado con lo indicado en el sitio del curso para el **Sprint 1: Diseño y Fundamentos de Datos**
(entregables: **reporte_diseño.pdf**, **script_limpieza.R**, **bitacora_ia_s1.xlsx**), y con el **Checklist de Reproducibilidad**.

## Estructura
- `scripts/` : scripts numerados y ejecutables
- `data/raw/` : datos crudos (NO modificar)
- `data/processed/` : datos limpios/listos para análisis
- `output/` : tablas/figuras exportadas
- `docs/` : reporte en Quarto/Rmd (se renderiza a PDF)

## Flujo recomendado (Sprint 1)
1) Ejecutar `scripts/00_setup_ambiente.R`
2) Colocar dataset(s) en `data/raw/`
3) Editar y ejecutar `scripts/01_importar_datos.R` (lee datos crudos)
4) Editar y ejecutar `scripts/02_limpieza_datos.R` (genera `data/processed/datos_limpios.*`)
5) (Opcional) Ejecutar `scripts/03_diccionario_datos.R` (exporta diccionario a `output/`)
6) Renderizar el reporte: `docs/reporte_diseno.qmd` → `docs/reporte_diseño.pdf`
7) Copiar/guardar la bitácora de IA como `bitacora_ia_s1.xlsx` en la carpeta de entrega.

## Reproducibilidad mínima
- No usar paths absolutos (usar `here::here()`)
- Listar paquetes al inicio del script
- Registrar `sessionInfo()` al final (ver `scripts/99_session_info.R`)

## Entrega (según repositorio del curso)
Subir **solo** los productos finales a:
`sp-8502-giact-2026/sprint-1/entregas/[carné]/`
- `reporte_diseño.pdf`
- `script_limpieza.R`
- `bitacora_ia_s1.xlsx`

> ⚠️ No subas datos sensibles. Si son datos de personas, anonimizá antes.
