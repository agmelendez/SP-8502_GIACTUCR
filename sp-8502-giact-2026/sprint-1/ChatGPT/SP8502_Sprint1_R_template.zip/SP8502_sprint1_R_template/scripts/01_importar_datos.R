# 01_importar_datos.R
# SP-8502 · Sprint 1 — Importación de datos
# Lee datos crudos desde /data/raw y guarda una copia estandarizada (si aplica).

library(here)
library(tidyverse)
library(readr)
library(readxl)

# ---- CONFIG: elige 1 opción ----
# Opción A: CSV
ruta_in <- here::here("data", "raw", "datos_crudos.csv")

# Opción B: Excel (descomenta y ajusta)
# ruta_in <- here::here("data", "raw", "datos_crudos.xlsx")
# hoja <- 1

# ---- Lectura ----
if (file.exists(ruta_in) && grepl("\\.csv$", ruta_in, ignore.case = TRUE)) {
  datos_raw <- readr::read_csv(ruta_in, show_col_types = FALSE)
} else if (file.exists(ruta_in) && grepl("\\.xlsx$", ruta_in, ignore.case = TRUE)) {
  # datos_raw <- readxl::read_excel(ruta_in, sheet = hoja)
  stop("Archivo .xlsx detectado: descomenta la lectura y define 'hoja'.")
} else {
  stop("No encuentro el archivo de entrada en: ", ruta_in,
       "\nColoca tus datos en data/raw/ y actualiza 'ruta_in'.")
}

# ---- Guardar copia estandarizada (opcional) ----
ruta_out <- here::here("data", "raw", "datos_raw_importados.rds")
saveRDS(datos_raw, ruta_out)

cat("OK: importados", nrow(datos_raw), "registros y", ncol(datos_raw), "variables.\n")
cat("Guardado:", ruta_out, "\n")
