# 00_setup_ambiente.R
# SP-8502 · Sprint 1 — Setup reproducible
# Objetivo: dejar el proyecto listo para leer/limpiar datos sin paths absolutos.

# 1) Paquetes ----
paquetes <- c(
  "here", "tidyverse", "janitor", "readr", "readxl",
  "lubridate", "stringr", "skimr"
)

# Instalar faltantes (SOLO la primera vez; comentar en entregas si el docente lo pide)
faltantes <- paquetes[!paquetes %in% installed.packages()[, "Package"]]
if (length(faltantes) > 0) install.packages(faltantes)

# Cargar
invisible(lapply(paquetes, library, character.only = TRUE))

# 2) Semilla (si vas a simular datos) ----
set.seed(8502)

# 3) Rutas del proyecto (sin paths absolutos) ----
cat("Raíz del proyecto:", here::here(), "\n")
cat("Carpeta data/raw:", here::here("data", "raw"), "\n")

# 4) Chequeo rápido ----
# Crear carpetas si no existen (por si se ejecuta fuera del repo)
dir.create(here::here("data", "raw"), recursive = TRUE, showWarnings = FALSE)
dir.create(here::here("data", "processed"), recursive = TRUE, showWarnings = FALSE)
dir.create(here::here("output"), recursive = TRUE, showWarnings = FALSE)

cat("Setup completado.\n")
