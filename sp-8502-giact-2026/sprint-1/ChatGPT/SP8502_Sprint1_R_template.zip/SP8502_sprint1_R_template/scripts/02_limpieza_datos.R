# 02_limpieza_datos.R  (este es tu "script_limpieza.R" base)
# SP-8502 · Sprint 1 — Limpieza reproducible
# Objetivo: producir un dataset limpio en /data/processed y dejar evidencia de decisiones.

library(here)
library(tidyverse)
library(janitor)
library(lubridate)
library(stringr)

# ---- Cargar datos importados ----
ruta_in <- here::here("data", "raw", "datos_raw_importados.rds")
if (!file.exists(ruta_in)) stop("No existe: ", ruta_in, "\nEjecuta antes 01_importar_datos.R")

datos <- readRDS(ruta_in)

# ---- Limpieza mínima recomendada ----
# 1) Nombres de variables consistentes
datos_limpios <- datos %>%
  janitor::clean_names()

# 2) Quitar espacios en textos (ejemplo)
datos_limpios <- datos_limpios %>%
  mutate(across(where(is.character), ~ str_squish(.x)))

# 3) Convertir fechas (EJEMPLO: ajusta al nombre real de tu variable)
# datos_limpios <- datos_limpios %>%
#   mutate(fecha = lubridate::ymd(fecha))

# 4) Manejo de NA / valores imposibles (EJEMPLOS: ajustar al caso)
# datos_limpios <- datos_limpios %>%
#   mutate(edad = if_else(edad < 0 | edad > 120, NA_real_, edad))

# ---- Validaciones rápidas (documentar en Bitácora IA / README) ----
cat("Filas:", nrow(datos_limpios), " | Columnas:", ncol(datos_limpios), "\n")
cat("NA totales:", sum(is.na(datos_limpios)), "\n")

# ---- Guardar outputs ----
ruta_out_csv <- here::here("data", "processed", "datos_limpios.csv")
ruta_out_rds <- here::here("data", "processed", "datos_limpios.rds")

readr::write_csv(datos_limpios, ruta_out_csv, na = "")
saveRDS(datos_limpios, ruta_out_rds)

cat("OK: dataset limpio guardado en:\n- ", ruta_out_csv, "\n- ", ruta_out_rds, "\n")
