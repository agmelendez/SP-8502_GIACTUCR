# 99_session_info.R
# SP-8502 — Evidencia de versiones
# Copia/pega la salida en README.md o en tu reporte (según te pidan).

sessionInfo()
