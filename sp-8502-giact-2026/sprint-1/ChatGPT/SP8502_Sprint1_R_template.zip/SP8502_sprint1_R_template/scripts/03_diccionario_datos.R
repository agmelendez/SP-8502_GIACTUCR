# 03_diccionario_datos.R
# SP-8502 · Sprint 1 — Diccionario de datos (mínimo)
# Genera un diccionario simple (nombre, tipo, ejemplo, %NA)

library(here)
library(tidyverse)

ruta_in <- here::here("data", "processed", "datos_limpios.rds")
if (!file.exists(ruta_in)) stop("No existe: ", ruta_in, "\nEjecuta antes 02_limpieza_datos.R")

df <- readRDS(ruta_in)

dic <- tibble(
  variable = names(df),
  clase = map_chr(df, ~ paste(class(.x), collapse = "/")),
  ejemplo = map_chr(df, ~ {
    v <- .x[!is.na(.x)]
    if (length(v) == 0) return(NA_character_)
    as.character(v[1])
  }),
  pct_na = map_dbl(df, ~ mean(is.na(.x)) * 100)
)

ruta_out <- here::here("output", "diccionario_datos_sprint1.csv")
readr::write_csv(dic, ruta_out)

cat("OK: diccionario guardado en", ruta_out, "\n")
